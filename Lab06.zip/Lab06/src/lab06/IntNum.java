package lab06;

import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;

public interface IntNum {

    abstract void store();
   
}
