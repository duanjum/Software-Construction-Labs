import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.HashMap;
import java.util.Map;
@Entity
@Table (name="CHC")
public class scheme {
    @Id
    protected String userId;
    protected String scheme;
    protected double timeTaken;
    protected boolean state;
    protected Map cTime=new HashMap();
    protected Map cStatus=new HashMap();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public double getTimeTaken() {
        return timeTaken;
    }

    public void setTimeTaken(double timeTaken) {
        this.timeTaken = timeTaken;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public Map getcTime() {
        return cTime;
    }

    public void setcTime(Map cTime) {
        this.cTime = cTime;
    }

    public Map getcStatus() {
        return cStatus;
    }

    public void setcStatus(Map cStatus) {
        this.cStatus = cStatus;
    }
    
    
          
}
