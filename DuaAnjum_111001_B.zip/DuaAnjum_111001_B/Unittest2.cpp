#include <iostream>
#include "RSystem.h"
#include <stdlib.h>
using namespace std;

void main(){

	//creating a schedule for 31 days of March
	//assessing hardcoding reservations
	Schedule S1[31];
	for (int i = 0; i < 31; i++)
	{
		//extra large table
		string names[12] = {};
		S1[i].T1.Reserve(10, "10/03/17", 50, names);
		for (int j = 0; j < 3; j++)
		{
			//large table
			S1[i].T2[j].Reserve(10, "10/03/17", 50, names);
		}
		for (int j = 0; j < 8; j++)
		{
			//medium table
			string names[4] = { "Dua Anjum", "Anam Baloch", "Maryam Hashmi", "Matthew Daddario" };
			S1[i].T2[j].Reserve(10, "10/03/17", 50, names);
		}
		for (int j = 0; j < 4; j++)
		{
			//small table
			string names[2] = { "Dua Anjum", "Anam Baloch" };
			S1[i].T2[j].Reserve(10, "10/03/17", 50, names);
		}

		S1[i].printSch(); //printing the schedule
	}



}
