#include <iostream>
#include "RSystem.h"
#include <stdlib.h>
using namespace std;

void main(){

//creating a schedule for 31 days of March
	//assessing user input
	Schedule S1[31];
	for (int i = 0; i < 31; i++)
	{
		//extra large table
		S1[i].T1.Reserve();
		for (int j = 0; j < 3; j++)
		{
			//large table
			S1[i].T2[j].Reserve();
		}
		for (int j = 0; j < 8; j++)
		{
			//medium table
			S1[i].T2[j].Reserve();
		}
		for (int j = 0; j < 4; j++)
		{
			//small table
			S1[i].T2[j].Reserve();
		}

		S1[i].printSch(); //printing the schedule
	}

	
	
}
