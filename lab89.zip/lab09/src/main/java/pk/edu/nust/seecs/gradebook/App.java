package pk.edu.nust.seecs.gradebook;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import pk.edu.gradebook.bo.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

public class App {

    public static void main(String[] args) {
 
        ApplicationContext context=new ClassPathXmlApplicationContext(new String[]{"application-context.xml"});
        BeanFactory factory=context;
        BO myBean=(BO)factory.getBean("bo");
        myBean.addClo(5,"a","b","c","d");
        
        
        myBean.printCloDao();
    
        

    }

}