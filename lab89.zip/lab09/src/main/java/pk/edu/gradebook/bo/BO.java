package pk.edu.gradebook.bo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.entity.Grade;
import pk.edu.nust.seecs.gradebook.entity.Student;
import pk.edu.nust.seecs.gradebook.entity.Teacher;


public class BO {
    private CloDao cloDao;
    private ContentDao contentDao;
    private CourseDao courseDao;
    private GradeDao gradeDao;
    private StudentDao studentDao;
    private TeacherDao teacherDao;
  

    public CloDao getCloDao() {
        return cloDao;
    }
    // task 4 and 6
    public void printCloDao(){
       cloDao=new CloDao();
      List<Clo> clos = new ArrayList<Clo>();
       clos= cloDao.getAllClos();
       for(Clo item:clos)
       {
           System.out.println(item.toString());
       }
       
    }

    public void setCloDao(CloDao cloDao) {
        this.cloDao = cloDao;
    }

    public ContentDao getContentDao() {
        return contentDao;
    }

    public void setContentDao(ContentDao contentDao) {
        this.contentDao = contentDao;
    }

    public CourseDao getCourseDao() {
        return courseDao;
    }

    public void setCourseDao(CourseDao courseDao) {
        this.courseDao = courseDao;
    }

    public GradeDao getGradeDao() {
        return gradeDao;
    }

    public void setGradeDao(GradeDao gradeDao) {
        this.gradeDao = gradeDao;
    }

    public StudentDao getStudentDao() {
        return studentDao;
    }

    public void setStudentDao(StudentDao studentDao) {
        this.studentDao = studentDao;
    }

    public TeacherDao getTeacherDao() {
        return teacherDao;
    }

    public void setTeacherDao(TeacherDao teacherDao) {
        this.teacherDao = teacherDao;
    }

    
    
    public void addClo(int a,String b,String c,String d,String e){
     CloDao clodao = new CloDao();

        // Add new clo
        Clo clo = new Clo();
        clo.setName(b);
        clo.setDescription(c);
        clo.setPlo(d);
        clo.setCloId(a);
        clo.setBtLevel(e);
        clodao.addClo(clo);

        clodao.updateClo(clo);
    
    }
        public void addCourse(int a,String b,Date d,Date e,int c){
     CourseDao codao = new CourseDao();

        // Add new clo
        Course course = new Course();
        course.setClasstitle(b);
        course.setStartsOn(d);
        course.setEndsOn(e);
        course.setCreditHours(c);
        
        codao.addCourse(course);

        codao.updateCourse(course);
    
    }
         public void addGrade(int a,String b,int c){
     GradeDao gradao = new GradeDao();

        // Add new clo
        Grade grade = new Grade();
        grade.setName(b);
        grade.setScore(c);
       
        
        gradao.addGrade(grade);

        gradao.updateGrade(grade);
    
    }
          public void addStudent(int a,String b){
     StudentDao studao = new StudentDao();

        // Add new clo
        Student student = new Student();
        student.setName(b);
        
        
        studao.addStudent(student);

        studao.updateStudent(student);
    
    }
           public void addTeacher(int a,String b){
     TeacherDao teadao = new TeacherDao();

        // Add new clo
        Teacher teacher = new Teacher();
        teacher.setName(b);
       
        
        teadao.addTeacher(teacher);

        teadao.updateTeacher(teacher);
    
    }
            public void addContent(int a,String b,String c,Date d,Date e){
     ContentDao condao = new ContentDao();

        // Add new clo
        Content clo = new Content();
        clo.setTitle(b);
        clo.setDescription(c);
        clo.setStarttime(d);
        clo.setEndtime(e);
        
        condao.addContent(clo);

        condao.updateContent(clo);
    
    }
}
