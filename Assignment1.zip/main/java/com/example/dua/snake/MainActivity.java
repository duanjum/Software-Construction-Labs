package com.example.dua.snake;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Random;

import javax.net.ssl.SNIServerName;

public class MainActivity extends AppCompatActivity {

    int p1Position, p2Position;
    HashMap<Integer,Integer> Snakes = new HashMap<>();
    HashMap<Integer,Integer> Ladders= new HashMap<>();
    boolean isOver = false;

    boolean turn = true;
    boolean snake=false;
    boolean ladder=false;
    private TextView status;

    /**if true then player's turn**/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        status = (TextView) findViewById(R.id.status);

        p1Position = 0;
        p2Position = 0;

        Snakes.put(54, 19);
        Snakes.put(90, 48);
        Snakes.put(99, 77);

        Ladders.put(9, 34);
        Ladders.put(40, 64);
        Ladders.put(67, 86);
    }

    int rollDice() {
        ImageView imgView = (ImageView) findViewById(R.id.Die);
        int[] dice = {R.drawable.d1, R.drawable.d2, R.drawable.d3, R.drawable.d4, R.drawable.d5, R.drawable.d6};
        Random r = new Random();
        int n = r.nextInt(6) +1;
        imgView.setImageResource(dice[n - 1]);
        addStatus("Dice Rolled and value is:" + String.valueOf(n));
        return n;
    }

    public void onClick(View view) {

        if (turn && !isOver) {

            int diceValue = rollDice();

            // If snake is set and you do not throw 6
            //if (snake && diceValue != 6) {
                // then you can't move
            //}

            if (!snake || diceValue == 6) {
                playerTurn(diceValue);
            }

            if (diceValue != 6) {
                if (!ladder) {
                    turn = false;

                    if (!isOver) {
                        addStatus("Computer's turn");
                        new Handler().postDelayed(
                                new Runnable() {

                                    @Override
                                    public void run() {
                                        int diceValue = rollDice();
                                        compTurn(diceValue);

                                        if (diceValue != 6) {
                                            turn = true;
                                        } else {
                                            run();
                                        }
                                    }
                                }, 1000);
                    }
                }
                else {
                    ladder = false;
                }
            } else {
                ladder = false;
                snake = false;
            }
        }

    }

    public void playerTurn(int die){
        p1Position+=die; //incrementing position
        if(p1Position==100) {
            isOver = true;
            Toast.makeText(this, "You Win!", Toast.LENGTH_SHORT).show();
        }
        else if (Snakes.get(p1Position) != null) {
            status.setText("You have found a snake at" + String.valueOf(p1Position));
            p1Position = Snakes.get(p1Position);
            snake=true;
            addStatus("Relocating to new postion at" + String.valueOf(p1Position));
        }
        else if (Ladders.get(p1Position)!=null){
            status.setText("Encountered a ladder at" + String.valueOf(p1Position));
            p1Position=Ladders.get(p1Position);
            ladder=true;
            addStatus("Relocating to new position at" + String.valueOf(p1Position));
        }
        else if(p1Position>100){
            p1Position-=die;
        }

        TextView pPos = (TextView) findViewById(R.id.playerPosition);
        pPos.setText("Player:" + String.valueOf(p1Position));

        if (p1Position>p2Position){
            addStatus("Player 1 has got the upperhand");
        }
        else{
            addStatus("Computer has got the upperhand");
        }

    }

    public void compTurn(int die) {
        p2Position += die; //incrementing position
        if (p2Position == 100) {
            isOver = true;
            Toast.makeText(this, "Computer Wins!", Toast.LENGTH_SHORT).show();
        } else if (Snakes.get(p2Position) != null) {
            addStatus("Snake encountered at " + String.valueOf(p2Position - die));
            p2Position = Snakes.get(p2Position);
            addStatus("Moving to " + String.valueOf(p2Position));
        } else if (Ladders.get(p2Position) != null) {
            addStatus("Ladder encountered at " + String.valueOf(p2Position - die));
            p2Position = Ladders.get(p2Position);
            addStatus("Moving to " + String.valueOf(p2Position));
        } else if (p2Position > 100) {
            p2Position -= die;
        }

        TextView cPos = (TextView) findViewById(R.id.computerPosition);
        cPos.setText("Computer:" + String.valueOf(p2Position));

        if (p1Position > p2Position) {
            addStatus("Player 1 has got the upperhand");
        } else {
            addStatus("Computer has got the upperhand");
        }
    }

    private void addStatus(String string) {
        ((ScrollView) findViewById(R.id.scroll)).fullScroll(View.FOCUS_DOWN);
        status.setText(status.getText().toString() + "\n" + string);
    }
}
