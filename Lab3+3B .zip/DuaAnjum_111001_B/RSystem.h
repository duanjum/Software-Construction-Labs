#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <string>

using namespace std;

class Table{
protected:
	int tableCount = 16;
public:
	void Reserve(){}
};

class eLarge :protected Table
{
public:
	int tableCount = 1;
	int Capacity = 12;
	int ResTotal = 0;
	int time, startTime, resNum = 0, totTime = 660;
	//time in minutes
	string guestNames[6], date;
public:
	void Reserve(){
		//max reservation time is morning to evening: 11 am to 10 pm
		cout << "Enter start time" << endl;
		cin >> startTime;
		cout << "Enter time duration for booking" << endl;
		//no restriction on time duration except opening and closing time
		if (totTime <= 0)
			cout << "All booked up!";
		else
			cin >> time;
		totTime -= time;
		cout << "Enter Date for booking: DD/MM/YY" << endl;
		cin >> date;
		for (int j = 0; j < 6; j++)
		{
			cout << "Enter Guest name" << endl;
			cin >> guestNames[j];
		}
		resNum++;
		ResTotal++;
	}
	//to hardcode reservations
	void Reserve(int StartT, string datet, int duration, string names[12])
	{
		startTime = StartT;
		date = datet;
		time = duration;
		for (int j = 0; j < 6; j++)
		{
			guestNames[j] = names[j];
		}
		resNum++;
		ResTotal++;
	}
	void Print(){
		cout << "Reservation Number" << resNum << endl;
		cout << "Date:" << date << endl;
		cout << "Time:" << startTime << endl;
		cout << "Guest Names" << guestNames[0] << " & " << guestNames[1] << " & " << guestNames[2] << " & " << guestNames[3] << " & " << guestNames[4] << " & " << guestNames[5] << endl;
	}
};

class nLarge :protected Table
{
public:
	int ResTotal = 0;
	int tableCount = 3;
	int time, startTime, resNum = 0, totTime = 660;
	//time in minutes
	string guestNames[6], date;
public:
	void Reserve(){
		//max reservation time is morning to evening: 11 am to 10 pm
		cout << "Enter start time" << endl;
		cin >> startTime;
		cout << "Enter time duration for booking" << endl;
		if (time > 70) //accounting for cooking and eating time
		{
			cout << "Duration greater than allowed. Enter Again" << endl;
		}
		if (totTime <= 0)
			cout << "All booked up!";
		else
		cin >> time;
		totTime -= time;
		cout << "Enter Date for booking: DD/MM/YY" << endl;
		cin >> date;
		for (int j = 0; j < 6; j++)
		{
			cout << "Enter Guest name" << endl;
			cin >> guestNames[j];
		}
		resNum++;
		ResTotal++;
	}
	//to hardcode reservations
	void Reserve(int StartT, string datet, int duration, string names[6])
	{
		startTime = StartT;
		date = datet;
		time = duration;
		for (int j = 0; j < 6; j++)
		{
			guestNames[j] = names[j];
		}
		resNum++;
		ResTotal++;
	}
	void Print(){
		cout << "Reservation Number" << resNum << endl;
		cout << "Date:" << date << endl;
		cout << "Time:" << startTime << endl;
		cout << "Guest Names" << guestNames[0] << " & " << guestNames[1] << " & " << guestNames[2] << " & " << guestNames[3] << " & " << guestNames[4] << " & " << guestNames[5] << endl;
	}
};

class medium :protected Table

{
public:
	int ResTotal = 0;
	int tableCount = 8;
	int time, startTime, resNum = 0, totTime = 660;
	//time in minutes
	string guestNames[4], date;
public:
	void Reserve(){
		//max reservation time is morning to evening: 11 am to 10 pm
		cout << "Enter start time" << endl;
		cin >> startTime;
		cout << "Enter time duration for booking" << endl;
		if (time > 70) //accounting for cooking and eating time
		{
			cout << "Duration greater than allowed. Enter Again" << endl;
		}
		if (totTime <= 0)
			cout << "All booked up!";
		else
		cin >> time;
		totTime -= time;
		cout << "Enter Date for booking: DD/MM/YY" << endl;
		cin >> date;
		for (int j = 0; j < 4; j++)
		{
			cout << "Enter Guest name" << endl;
			cin >> guestNames[j];
		}
		resNum++;
		ResTotal++;
	}
	//to hardcode reservations
	void Reserve(int StartT, string datet, int duration, string names[4])
	{
		startTime = StartT;
		date = datet;
		time = duration;
		for (int j = 0; j < 4; j++)
		{
				guestNames[j]=names[j];
		}
		resNum++;
		ResTotal++;
	}
	void Print(){
		cout << "Reservation Number" << resNum << endl;
		cout << "Date:" << date << endl;
		cout << "Time:" << startTime << endl;
		cout << "Guest Names" << guestNames[0] << " & " << guestNames[1]<<" & " << guestNames[2]<<" & " << guestNames[3] << endl;
	}
};

class small :protected Table
{
public:
	int ResTotal = 0;
	int tableCount = 4;
	int time, startTime, resNum=0, totTime=660;
	//time in minutes
	string guestNames[2], date;
public:
	//should also add condition to ensure no overloading
	void Reserve(){
		//max reservation time is morning to evening: 11 am to 10 pm
		cout << "Enter start time" << endl;
		cin >> startTime;
		cout << "Enter time duration for booking" << endl;
		if (time > 70) //accounting for cooking and eating time
		{
			cout << "Duration greater than allowed. Enter Again" << endl;
		}
		if (totTime <= 0)
			cout << "All booked up!";
		else
		cin >> time;
		totTime -= time;
		cout << "Enter Date for booking: DD/MM/YY" << endl;
		cin >> date;
		for (int j = 0; j < 2; j++)
		{
			cout << "Enter Guest name" << endl;
			cin >> guestNames[j];
		}
		resNum++;
		ResTotal++;
	}
	//to hardcode reservations
	void Reserve(int StartT, string datet, int duration, string names[2])
	{
		startTime = StartT;
		date = datet;
		time = duration;
		guestNames[0] = names[0];
		guestNames[1] = names[1];
		resNum++;
		ResTotal++;
	}
	void Print(){
		cout << "Reservation Number" << resNum << endl;
		cout << "Date:" << date << endl;
		cout << "Time:" << startTime << endl;
		cout << "Guest Names" << guestNames[0] << " & " << guestNames[1] << endl;
	}
	
};
//Schedule for one day printing and print for all days by batch using unit test
class Schedule{
public:
	eLarge T1;
	nLarge T2[3];
	medium T3[8];
	small T4[4];

public:
	void printSch(){
		//printing reservations for all small tables
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < T4[i].ResTotal; j++)
			{
				T4[i].Print();
			}
		}
		//printing reservations for all medium tables
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < T3[i].ResTotal; j++)
			T3[i].Print();
		}
		//printing reservations for all Large tables
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < T2[i].ResTotal; j++)
			T2[i].Print();
		}
		//printing reservations for the extra large table
		for (int i = 0; i < T1.ResTotal ; i++)
		{
			T3[i].Print();
		}
	

	}
 
};