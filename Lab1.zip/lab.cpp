/* Dua Anjum
	Lab 01 Software Construction*/

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

// Channel class -> NODE

class Channel {

	string name;
	string path;
	string desc;
	Channel* next;

public:

	Channel() { next = NULL; };

	void SetData(string aname, string apath, string adesc) { name = aname;  path = apath; desc = adesc; };

	void SetNext(Channel* aNext) { next = aNext; };

	void Data() { cout << "--" << path << "--"; cout << name << "--"; cout << desc << "--"; };

	void Desc() { cout << desc << "--"; };
	//returning ID for parsing in delete
	string Search(){ return name; }

	Channel* Next() { return next; };

};

// TV_Manager class -> LIST

class TV_Manager {

	Channel *head;

	//to keep track 
	static int numChannels;
public:

	TV_Manager() { head = NULL; };

	void Print();
	void Print_Desc();

	void Append(string aname, string path, string adesc);

	void Delete(string name);

	void Replace(string oldname, string newname, string path, string desc);

	int getsize(){ return numChannels; };
};
int TV_Manager::numChannels = 0; //initializing count static variable



// Print the contents of the TV_Manager
void TV_Manager::Print() {

	// Temp pointer

	Channel *tmp = head;

	// No Channels

	if (tmp == NULL) {

		cout << "EMPTY" << endl;

		return;

	}

	// One Channel in the TV_Manager

	if (tmp->Next() == NULL) {

		tmp->Data();

		cout << " --> ";

		cout << "NULL" << endl;

	}

	else {

		// Parse and print the TV_Manager

		do {

			tmp->Data();

			cout << " --> ";

			tmp = tmp->Next();

		}

		while (tmp != NULL);

		cout << "NULL" << endl;

	}

}

void TV_Manager::Print_Desc() {

	// Temp pointer

	Channel *tmp = head;

	// No Channels

	if (tmp == NULL) {

		cout << "EMPTY" << endl;

		return;

	}

	// One Channel in the TV_Manager

	if (tmp->Next() == NULL) {

		tmp->Data();

		cout << " --> ";

		cout << "NULL" << endl;

	}

	else {

		// Parse and print the TV_Manager

		do {

			tmp->Desc();

			cout << " --> ";

			tmp = tmp->Next();

		}

		while (tmp != NULL);

		cout << "NULL" << endl;

	}

}


//Append a Channel to the linked TV_Manager
void TV_Manager::Append(string aname, string apath, string adesc) {

	// Create a new Channel

	Channel* newChannel = new Channel();

	newChannel->SetData(aname, apath, adesc);

	newChannel->SetNext(NULL);

	// Create a temp pointer

	Channel *tmp = head;

	if (tmp != NULL) {

		// Channels already present in the TV_Manager

		// Parse to end of TV_Manager

		while (tmp->Next() != NULL) {

			tmp = tmp->Next();

		}

		// Point the last Channel to the new Channel

		tmp->SetNext(newChannel);

	}

	else {

		// First Channel in the TV_Manager

		head = newChannel;

	}
	numChannels++; // incremented number of created Channels
}

void TV_Manager::Replace(string oldname, string newname, string path, string adesc) {
	// Create a temp pointer

	Channel *tmp = head;

	// No Channels

	if (tmp == NULL)

		return;

	// Last Channel of the TV_Manager

	if (tmp->Next() == NULL) {

		delete tmp;

		head = NULL;

	}

	else {

		// Parse thru the Channels

		Channel *prev;

		do {

			if (tmp->Search() == oldname) break;

			prev = tmp;

			tmp = tmp->Next();

		} while (tmp != NULL);

		// Adjust the pointers

		tmp->SetData(newname, path, adesc);

	}

}

// Delete a Channel from the TV_Manager
void TV_Manager::Delete(string aname) {

	// Create a temp pointer

	Channel *tmp = head;

	// No Channels

	if (tmp == NULL)

		return;

	// Last Channel of the TV_Manager

	if (tmp->Next() == NULL && tmp->Search() == aname) {
		

		delete tmp;

		head = NULL;

	}
	else if (tmp->Search() == aname)
	{
		head = head->Next();
		delete tmp;

	}

	else {

		// Parse thru the Channels

		Channel *prev =NULL;

		do {

			if (tmp->Search() == aname) break;

			prev = tmp;

			tmp = tmp->Next();

		} while (tmp != NULL);

		// Adjust the pointers

		prev->SetNext(tmp->Next());

		// Delete the current Channel

		delete tmp;

	}

}

int main() //TASK 6

{

	// New TV_Manager

	TV_Manager TV_Manager;

	// Append Channels to the TV_Manager

	//hardcoded
	//adding new channel to list
	TV_Manager.Append("News", "https://www.youtube.com/user/GirlsPk1", "GET WITH ALL THE GLOBAL NEWS");
	TV_Manager.Append("Chilli Tomato Noodle", "https://www.youtube.com/user/ChiliTomatoNoodle", "Programming Tutorials");
	TV_Manager.Append("Ed Sheeran", "https://www.youtube.com/channel/UC0C-w0YjGpqDXGB8IHb662A", "Musical Genius");
	
	//TV_Manager.Print();
	bool flag = 1;
	while (flag != 0){
		int option;
		cout << "To enter a new  Channel Press 1. \n To replace existing channel Press 2.\n To remove an exiting Channel Press 3.\n To print channel description Press 4.\n  Press 0 to exit.\n " << endl;
		cin >> option;//by user entry
		//print method usage shown in all below

		switch (option) { //Add Method usage: TASK 1
		case 1:
		{string cname, cpath, desc;
		cout << "Enter name:" << endl;
		cin >> cname;
		cout << "Enter Path/URL:" << endl;
		cin >> cpath;
		cout << "Enter Description:" << endl;
		cin >> desc;
		TV_Manager.Append(cname, cpath, desc);
		TV_Manager.Print();
		break; }
		
		case 2: //replace method usage: TASK 2
		{string oname, nname, cpath, desc;
		cout << "Enter old name:" << endl;
		cin >> oname;
		cout << "Enter new name:" << endl;
		cin >> nname;
		cout << "Enter Path/URL:" << endl;
		cin >> cpath;
		cout << "Enter Description:" << endl;
		cin >> desc;
		TV_Manager.Replace(oname, nname, cpath, desc);
		TV_Manager.Print();
		break; }

		case 3://remove method usage: TASK 3
		{string cname;
		cout << "Enter name:" << endl;
		cin >> cname;
		TV_Manager.Delete(cname);
		TV_Manager.Print();
		break; }

		case 4: //TASK 4
		{TV_Manager.Print_Desc();
		 break;
		}
		case 0:
			exit (0);

		}
		
			
		//code to play video from channel! TASK 5

		

	}
	
	
}

